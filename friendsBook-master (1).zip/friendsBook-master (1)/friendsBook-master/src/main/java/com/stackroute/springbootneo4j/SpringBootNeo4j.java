package com.stackroute.springbootneo4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootNeo4j {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootNeo4j.class, args);
	}
}
